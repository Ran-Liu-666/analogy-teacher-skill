# Analogy Teacher — 论文精读 + 引文学习 + Idea 发现

[![Version](https://img.shields.io/badge/version-2.2.0-blue)](SKILL.md)
[![Platform](https://img.shields.io/badge/platform-Claude%20Code-orange)](https://claude.ai/code)

> **"如果你不能用生活例子解释一个概念，你就没有真正理解它。"**

Analogy Teacher 是一个 Claude Code 技能，将任意论文的任意页面转化为**零基础可独立阅读的完整教材**。它不是论文摘要器，不是翻译工具，而是一个真正的**教师**——用生活类比、手算例子、逐符号翻译和工程直觉，帮助读者从"完全不懂"到达"闭着眼睛也能复述"的理解深度。

---

## 🎯 三大核心能力

### 📖 论文精读（Paper Reading）
- **Two-Pass 架构**：先提取后教学，绝不混合，确保每个解释都有论文原文锚点
- **四层递进教学**：生活类比 → 数值算例 → 形式化翻译 → 工程直觉
- **15 条红线自审**：可测试的质量禁令，确保教学输出不偷工减料
- **7 种论文类型自适应**：methods / discovery / resource / clinical / materials / review / conceptual
- **WYSIATI 认知校准**：基于 Kahneman 双过程理论，防止"所见即全部"偏差
- **三层读图法**：看懂内容 → 检查信息完整性 → 识别图表在论证中的角色
- **6 项视觉易错检查**：帮学习者识别图表中容易被误导的 6 种情况
- **19 节固定教学输出**：每页都有完整的教学卡片结构

### 🔗 引文学习（Reference Mining）
- 参考文献四类分类（基石/竞争/工具/背景文献）
- 7 级证据层级评估（系统综述→专家观点）
- 方法谱系追踪 + ASCII 谱系图
- 基石文献深度追踪（借了什么？做了什么改进？）

### 💡 Idea 发现（Idea Engine）
- **7 种生成策略**：假设松弛 / 组件替换 / 跨领域移植 / 极限测试 / 反向思考 / Future Work / 组合爆炸
- **4 道品质关卡**：源追溯 → 新颖性区分 → 可行性 → 非发明
- 每个 Idea 附带标准输出模板（可直接用于开题/立项）

---

## 🚀 快速开始

### 安装

将本仓库克隆到 Claude Code 的 skills 目录：

```bash
# 创建 skills 目录（如果不存在）
mkdir -p ~/.claude/skills

# 克隆本仓库
git clone https://github.com/YOUR_USERNAME/analogy-teacher.git ~/.claude/skills/analogy-teacher
```

### 触发

安装后，在新对话中说以下任意自然语句即可激活：

| 你想做什么 | 这样说 |
|-----------|--------|
| 精读论文 | `讲懂我` `打个比方` `零基础` `精读这篇论文` `读论文` `论文第X页` |
| 学习引用论文 | `学习引用论文` `追踪方法谱系` `这个方法从哪里来的` |
| 找研究 Idea | `找Idea` `有什么可做的` `研究空白` `未来方向` |

首次触发时，技能会先询问你的知识水平（🌱零基础 / 🌿初学者 / 🌳进阶者 / 🎓研究者），然后根据你的水平自适应调整教学深度。

---

## 🏗️ 架构总览（v2.2）

```
Gate 0: 学习者水平评估 → 4级自适应教学
    ↓
Pass 1: 结构提取（只读）
    ├── 论文类型分类（7种原型）
    ├── 术语账本构建
    ├── 证据清单 + 声明-证据矩阵
    └── 块ID锚定 [B###][E###][F###]
    ↓
[Gate: 用户确认]
    ↓
Pass 2: 教学写作
    ├── 类型特定的教学模板
    ├── 四层递进 + 八个协议
    ├── WYSIATI 认知校准检查点
    └── 15条红线自审
    ↓
输出: 19节固定教学卡片 → 保存到桌面
```

| 版本 | 行数 | 核心新增 |
|------|:---:|------|
| v2.2 | 2,078 | 学习者水平自适应（4级） |
| v2.1 | 2,001 | 读图协议（三层读图+6易错检查）+ 作图协议（Python/Mermaid） |
| v2.0 | 1,491 | Two-Pass 架构、15条红线、论文类型分类、WYSIATI |

---

## 📁 文件结构

```
analogy-teacher/
├── SKILL.md              # 主技能文件（2,078行）— Claude Code 自动加载
├── README.md             # 本文件
└── examples/             # 示例输出
    └── EXAMPLE.md        # 一页论文的完整教学输出示例
```

---

## 🤝 贡献

欢迎提交 Issue 和 Pull Request。在提交 PR 之前，请确保：
- 修改不破坏现有的 15 条红线自审逻辑
- 新增内容与 19 节固定输出模式兼容
- Markdown 语法正确，表格对齐

---

## 📄 许可

本技能基于 Claude Code Skill 开放标准构建。源代码以 MIT 许可发布。

---

## 🙏 致谢

本技能的设计借鉴了以下 Claude Code 技能生态中的最佳实践：
- **nature-reader** — 术语账本、源锚定架构
- **nature-reviewer** — 15 条红线、洞察 ID 系统
- **nature-paper-card** — 16 节固定卡片模式（启发 19 节输出）
- **citation-check-skill** — Two-Pass 架构
- **survey** — WYSIATI 认知校准（Kahneman 双过程理论）
- **scipilot-figure-skill** — 图表反欺骗检查、色盲安全配色
- **scientific-figure-generator** — 论文类型→图表结构映射
- **paper-spine** — 贡献优先方法论、防跳过规则
- **academic-paper** — 反泄漏协议、故障路径目录
- **thesis-writing** — 状态文件 + 强制暂停关卡
