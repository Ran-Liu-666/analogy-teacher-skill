# Analogy Teacher

> **"如果你不能用生活例子解释一个概念，你就没有真正理解它。"**

一个 Claude Code skill，用生活化类比把任何复杂学术概念翻译成零基础可理解的内容。论文公式、实验指标、算法机制——都变成你每天能见到的东西。

## 快速开始

在 Claude Code 中，直接说任何你觉得自然的句子即可触发：

```
讲懂我调和函数
把这篇论文第五页从零基础讲懂
用生活中的例子解释 PDR
帮我打个比方：什么是 Laplace 方程？
现在用类比解释 Scheme α 和 Scheme β 的区别
```

## 能做什么

| 你说 | 你得到 |
|------|--------|
| "讲懂我这个公式" | 生活类比 + 数值算例 + 人话翻译 + 工程直觉 |
| "把这篇论文第X页讲懂" | 逐段逐概念的系统精讲，配套 ASCII 示意图 |
| "用类比解释 A 和 B 的区别" | 一对"平行宇宙"隐喻，比如"橡皮筋上的小球 vs 探照灯越野车" |
| "精读这篇论文" | 完整论文精读报告，输出为 markdown 文件到桌面 |

## 安装

```bash
# 放到你项目的 .claude/skills/ 目录下
cp -r analogy-teacher ~/你的项目/.claude/skills/analogy-teacher
```

或者放到用户级 skills 目录（所有项目可用）：

```bash
cp -r analogy-teacher ~/.claude/skills/analogy-teacher
```

不用记任何命令。说人话就行。
