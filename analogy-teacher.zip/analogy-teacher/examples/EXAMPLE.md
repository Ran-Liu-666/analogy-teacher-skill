# 示例对话：Analogy Teacher 实战

以下是使用 Analogy Teacher skill 的实际对话效果展示。

---

## 示例 1：单概念解释

**用户**：讲懂我 Jacobi 迭代

**Claude**：

### Jacobi 迭代

**学术定义**：一种求解线性方程组的迭代方法，每轮用上一轮的邻居值计算当前节点的新值。

**生活类比**：
```
五个人要决定周末去哪吃饭，预算是人均花费。

第一轮：每个人随便说一个数
  张三:100, 李四:200, 王五:150, 赵六:180, 你:120

第二轮开始，每个人取"朋友们的上一轮预算平均值"：
  你(新) = (张三旧 + 李四旧 + 王五旧 + 赵六旧) / 4
         = (100 + 200 + 150 + 180) / 4 = 157.5

  注意：你用的是"上一轮"的数字，不是边算边用！
  这就是 Jacobi 风格。
```

**数值示例**：
```
初始：
  1.0   1.0   1.0
  1.0   0.5   1.0    ← 中间值 0.5
  1.0   1.0   1.0    ← 边界全固定 1.0

第1轮（中间点）：
  新值 = (1.0+1.0+1.0+1.0)/4 = 1.0
  从 0.5 变成了 1.0 ✓

第50轮后：全场收敛到 1.0（被边界"拉平"了）
```

**工程直觉**：Jacobi 迭代用"旧值"算"新值"，天然适合并行——100个节点可以同时更新，谁也不用等谁。

---

## 示例 2：两个方案对比

**用户**：用类比解释 α 和 β 两种路由方案的区别

**Claude**：

### Scheme α vs Scheme β

**一对平行隐喻**：

```
        橡皮筋上的小球 (α)              探照灯越野车 (β)

        目标 ●                           目标 ●
          ↑                                ↑
      ╱╲  │ 拉力                        ╱╲  │
     ╱⚡╲ │                            ╱⚡╲ │ 探测到阻挡
    ╱干扰╲│                           ╱干扰╲│ 主动绕行
   ╱      ╲                          ╱      ╲
  ●球      │                        ●车      │
           │                                 │
  拉力够大→翻过去                     看见障碍→绕过去
  拉力不够→绕山走                     不管绕多远，不穿越
```

| | α（橡皮筋小球）| β（探照灯越野车）|
|---|---|---|
| 方向偏好 | sigmoid 乘法隐式奖励朝向目标 | 阻挡区域明确禁止某些方向 |
| 穿越干扰 | **可能**（拉力 > 翻山成本时）| **不会**（阻挡区是硬约束）|
| 路径 | 尽量短 | 尽量平坦 |
| 回溯 | 极少 | 经常 |
| 适合场景 | 延迟敏感 | 丢包容忍度低 |

---

## 示例 3：整页精读（节选）

**用户**：把这篇论文第五页从零基础讲懂

**Claude**：

*(展开为十步递进教学，从"一滴墨水扩散"讲起，经过离散化、Jacobi迭代、非均匀推广、到两个调和函数定理，最后回到系统流程图。每一步都配生活类比、数值算例、公式人话翻译。详见 `D:\桌面\论文第五页详解_零基础教学.md`)*

---

## 示例 4：英文触发

**User**: teach me PDR like I'm 5

**Claude**:

### PDR (Packet Delivery Ratio)

**The "Post Office" Analogy**:

```
You send 100 letters to your friend.
If the post office loses 5 of them and 95 arrive safely,
your PDR = 95%.

Now imagine there's a loud construction site (interference!)
right next to the post office. The postman can't hear properly,
so he puts some letters on the wrong truck.

More construction noise → more lost letters → lower PDR.
```

**Engineering Intuition**: PDR is how we measure if a wireless link is "good enough" to send important data through. If PDR < 90%, you probably want a different route.
